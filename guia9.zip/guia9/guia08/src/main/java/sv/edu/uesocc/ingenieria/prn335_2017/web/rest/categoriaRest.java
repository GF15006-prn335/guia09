/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sv.edu.uesocc.ingenieria.prn335_2017.web.rest;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import javax.ejb.EJB;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import sv.edu.uesocc.ingenieria.prn335_2017.datos.acceso.CategoriaFacadeLocal;
import sv.edu.uesocc.ingenieria.prn335_2017.datos.definiciones.Categoria;

/**
 *
 * @author jacque
 */
@Path("Categoria")
public class categoriaRest implements Serializable{
    @EJB
    private CategoriaFacadeLocal catFac;
 
    
    
    //findAll
    /**
     * Este método encontrará todas las categorias de la DB
     * @return Una lista con las categorias
     */
    @GET
    @Produces({MediaType.APPLICATION_JSON})
    public List<Categoria> findAll(){
            try {
                 if(catFac!=null){
                return catFac.findAll();
            }
            } catch (Exception e) {
                System.out.println("err");
        }
        return Collections.EMPTY_LIST; 
    }
    
    //findbyRange
    /**
     * Este método encontrará todas las categorias de la DB segun un rango
     * @param first este es el limite inferior del rango de busqueda
     * @param pageSize este es el limite superior del rango de busqueda
     * @return debolverá las categorias según el rango establecido
     */
    @GET
    @Path("range")
    @Produces({MediaType.APPLICATION_JSON})
    public List<Categoria> findRange(
            @DefaultValue("0") @QueryParam("first")int first,
            @DefaultValue("10") @QueryParam("pagesize")int pageSize){
        List salida =null;
        try {
            if (catFac!=null) {
          salida=catFac.findRange(first,pageSize);
            }
        } catch (Exception e) {
            System.out.println("err");
        }finally{
            if(salida==null){
                salida=new ArrayList();
            }
        }
        return salida;
    }
    
     /**
      * Este método encontrará las categorias de la DB de acuerdo a un ID
      * @param id recibirá un entero de parámetro
      * @return debolverá la categoria según el id establecido
      */
    
    @GET
    @Path("{idCategoria}")
    @Produces({MediaType.APPLICATION_JSON})
     public Categoria findID(@PathParam("idCategoria") Integer id){
            try {
                 if(catFac!=null){
                return catFac.find(id);
            }
            } catch (Exception e) {
                System.out.println("err");
        }
        return new Categoria(); 
     }
     
     
     @POST
     @Produces({MediaType.APPLICATION_JSON})
     public Categoria create(Categoria nueva){
         
         if(nueva!=null && nueva.getIdCategoria()==null){
             try {
                 if(catFac!=null){
            Categoria  niu = catFac.create(nueva);
                if(niu!=null){
                     return niu;
                 }
                 }
            
                 
             } catch (Exception e) {
                 System.out.println("err");
             }
             
         }
        return new Categoria();
         
     } 
     
     
     
     @POST
     @Produces({MediaType.APPLICATION_JSON})
     @Consumes({MediaType.APPLICATION_JSON})
    public Categoria edit(Categoria modificada){
         if(modificada!=null){
             try {
             Categoria niu = catFac.edit(modificada);
             if(niu!=null){
                return niu;
                
             }
             
         } catch (Exception e) {
                 System.out.println("err");
         }
      
         }
         
  return new Categoria();
         
     }
    
    @DELETE
    @Path("{idCategoria}")
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    public Categoria eliminar(@PathParam("idCategoria") int id){
        if(id > 0){
            try {
                if (catFac != null) {
                    Categoria niu = catFac.remove(catFac.find(id));
                    if(niu!=null){
                        return niu;
                    }
                }
            } catch (Exception e) {
                System.out.println("err");
            }
        }
        return new Categoria();
    }

}
     
  
     
     /*
     
     @POST
     @Produces({MediaType.APPLICATION_JSON})
     @Consumes({MediaType.APPLICATION_JSON})
     public Response create(Categoria nueva){
         
          if(nueva!=null && nueva.getIdCategoria()==null){
             try {
                 if(catFac!=null){
          catFac.create(nueva);
          return Response.ok().entity(nueva).build();
                 }
                 
             } catch (Exception e) {
                 System.out.println("err");
             }
             
         } 
         
         return Response.status(Status.INTERNAL_SERVER_ERROR).build();
     }
     

          
     @PUT
     @Produces({MediaType.APPLICATION_JSON})
     @Consumes({MediaType.APPLICATION_JSON})
     @Path("{idCategoria}")
     public Response edit(
     @PathParam("idCategoria") int id, Categoria modificada){
         
         try {
             Categoria niu = catFac.find(new Categoria(id));
             if(niu!=null){
                 catFac.edit(modificada);
                 return Response.ok().entity(modificada).build();
             }else{
                 return Response.status(Status.NOT_FOUND).build();
             }
             
         } catch (Exception e) {
         }
         
return Response.status(Status.INTERNAL_SERVER_ERROR).build();
         
     }
     
     
     @DELETE
     @Path("{idCategoria}")
     public Response remove(
     @PathParam("idCategoria") int id){
         try {
             catFac.remove(new Categoria(id));
             return Response.ok().build();
         } catch (Exception e) {
         }
        return Response.status(404).build();
         
     }
     */
     
     

   


   

