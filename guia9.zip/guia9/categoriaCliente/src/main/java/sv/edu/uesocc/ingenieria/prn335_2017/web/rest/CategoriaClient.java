/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sv.edu.uesocc.ingenieria.prn335_2017.web.rest;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.view.ViewScoped;
import javax.inject.Named;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.GenericType;
import javax.ws.rs.core.MediaType;
import org.primefaces.event.SelectEvent;
import sv.edu.uesocc.ingenieria.prn335_2017.datos.definiciones.Categoria;


@Named
@ViewScoped
public class CategoriaClient implements Serializable {

    private WebTarget target;
    private Client client;
    List<Categoria> list;
    
    
    List<Categoria> lista= new ArrayList<>();
    Categoria cat =new Categoria();
List<Categoria> filtroCat= new ArrayList<>();



boolean activo,visible=true;

    public boolean isVisible() {
        return visible;
    }

    public void setVisible(boolean visible) {
        this.visible = visible;
}
    
    
    /**
     * Este es el constructor donde se instancia el cliente
     */

    public CategoriaClient() {
        try {
            client = ClientBuilder.newClient();
            target = client.target("http://localhost:8080/guia07-1.0-SNAPSHOT/webresources/Categoria");
        } catch (Exception e) {
            Logger.getLogger(getClass().getName()).log(Level.SEVERE, e.getMessage(), e);
        }
    }
    
    /**
     * Este metodo busca todas las categorias registradas
     * @return 
     */

    public List findAll() {
        List<Categoria> salida = null;
        try {
            salida = target.request(MediaType.APPLICATION_JSON).get(new GenericType<List<Categoria>>() {});
        } catch (Exception e) {
            Logger.getLogger(getClass().getName()).log(Level.SEVERE, e.getMessage(), e);
        } finally {
            if (salida == null) {
                salida = new ArrayList();
            }
        }
        return salida;
    }
    
   
    
    
     public List<Categoria> findRange(int first,int pageSize){
        List<Categoria> salida=null;
        try {
           target = client.target
        ("http://localhost:8080/guia07-1.0-SNAPSHOT/webresources/Categoria").path("range").
        queryParam("first",0).queryParam("pageSize",10);
            salida= target.request(MediaType.APPLICATION_JSON).
                    get(new GenericType<List<Categoria>>(){});
        } catch (Exception ex) {
            Logger.getLogger(getClass().getName()).log(Level.SEVERE, ex.getMessage(), ex);

        }finally{
            if(salida==null){
                salida= new ArrayList<>();
            }
        }
         return salida;
    }
      
      public List<Categoria> findById(Integer id){
        List<Categoria> salida=null;
        try {
            target =client.target
        ("http://localhost:8080/guia07-1.0-SNAPSHOT/webresources/Categoria").
                    path("{idCategoria}").resolveTemplate("idCategoria",id);
            salida= target.request(MediaType.APPLICATION_JSON).
                    get(new GenericType<List<Categoria>>(){});
        } catch (Exception ex) {
            Logger.getLogger(getClass().getName()).log(Level.SEVERE, ex.getMessage(), ex);

        }finally{
            if(salida==null){
                salida= new ArrayList<>();
            }
        }
         return salida;
    }
   
      
      
   
      public Categoria create(){
          
          if (cat!=null && cat.getIdCategoria()==null) {
              try {
                  if(client!=null)
                      target=client.target("http://localhost:8080/guia07-1.0-SNAPSHOT/webresources/Categoria");
                  Categoria salida =target.request(MediaType.APPLICATION_JSON).post(Entity.entity(cat, MediaType.APPLICATION_JSON),Categoria.class);
                  if (salida!=null && salida.getIdCategoria()==null) {
                      return salida;
                  }
              } catch (Exception ex) {
                       Logger.getLogger(getClass().getName()).log(Level.SEVERE, ex.getMessage(), ex);
              }
          }
          
        return null;
          
      }
      
      public Categoria edit() {
       
        if (cat != null) {
            try {
              Categoria salida = client.target("http://localhost:8080/guia07-1.0-SNAPSHOT/webresources/Categoria")
                        .request(MediaType.APPLICATION_JSON).put(Entity.entity(cat, MediaType.APPLICATION_JSON),Categoria.class);
                    llenar();
                    return salida;
            } catch (Exception e) {
                System.out.println("err");
            }
        }
        return null;
}
      
      public Categoria eliminar() {
 
        if (cat!= null) {
            try {
                Categoria salida = client.target("http://localhost:8080/guia07-1.0-SNAPSHOT/webresources/Categoria")
                        .path(cat.getIdCategoria().toString()).request(MediaType.APPLICATION_JSON).delete(Categoria.class);
                llenar();
                    return salida;
            } catch (Exception e) {
                System.out.println("err " );
            }
        }
        return null;
}
      

    public void llenar(){
       cat = new Categoria();
        try {
            lista = client.target("http://localhost:8080/guia07-1.0-SNAPSHOT/webresources/Categoria")
                    .request(MediaType.APPLICATION_JSON).get(new GenericType<List<Categoria>>() {});
        } catch (Exception e) {
            System.out.println("ex: " + e);
        }
   }
    @PostConstruct
    public void init(){
       llenar();
}
    
    //getters y setters de la lista

    public List<Categoria> getSalida() {
        return list;
    }

    public void setSalida(List<Categoria> salida) {
        this.list = list;
    }
    
    public void close() {
        client.close();
    }

    
    
 public void onRowSelect(SelectEvent event) {
       cat = (Categoria) event.getObject();
        visible=false;
     }
  
     public void cancelar(){
         cat= new Categoria();
         visible=true;
     }
     
     public void nuevo(){
         visible=false;
     }
     
     
    public List<Categoria> getFiltroCat() {
        return filtroCat;
    }
    public void setFiltroCat(List<Categoria> filtroCat) {
        this.filtroCat = filtroCat;
    }
    
    Categoria selectedCat;

    public Categoria getSelectedCat() {
        return selectedCat;
    }

    public void setSelectedCat(Categoria selectedCat) {
        this.selectedCat = selectedCat;
}

    public WebTarget getTarget() {
        return target;
    }

    public void setTarget(WebTarget target) {
        this.target = target;
    }

    public Client getClient() {
        return client;
    }

    public void setClient(Client client) {
        this.client = client;
    }

    public List<Categoria> getList() {
        return list;
    }

    public void setList(List<Categoria> list) {
        this.list = list;
    }

    public List<Categoria> getLista() {
        return lista;
    }

    public void setLista(List<Categoria> lista) {
        this.lista = lista;
    }

    public Categoria getCat() {
        return cat;
    }

    public void setCat(Categoria cat) {
        this.cat = cat;
    }

    public boolean isActivo() {
        return activo;
    }

    public void setActivo(boolean activo) {
        this.activo = activo;
    }
    
    
    
}
